package list2;

class ExplicitCast {
    public static void main(String[] args) {

        long l = 10;
        double d = l; // неявное приведение (long в double)
        l = (long) d; // явное приведение (double в long)

    }// main (String[])
} // ExplicitCast class