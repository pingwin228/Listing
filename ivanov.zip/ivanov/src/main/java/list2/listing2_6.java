package list2;
// сохраните исходный код в файле с именем CharArithDemo.java
class CharArithDemo {
    public static void main(String[] arge){
        char ch;
        ch='L';
        System.out.println(" ch равно "+ch);
        ch++;
        System.out.println(" значение ch изменилось на "+ch);
        ch='Д';
        ch--;
        System.out.println(" значение ch нова изменилось и  "+ch);
    }//main(String[])
}//CharArithDemo class
